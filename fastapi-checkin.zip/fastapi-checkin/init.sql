CREATE TABLE IF NOT EXISTS attendees (
    reg_code         CHAR(6)      PRIMARY KEY,
    seat_number      VARCHAR(10)  NOT NULL,
    table_number     VARCHAR(10)  NOT NULL,
    is_signed        BOOLEAN      DEFAULT FALSE,
    verify_hash_code VARCHAR(64)  DEFAULT NULL,
    result           BOOLEAN      DEFAULT FALSE
);