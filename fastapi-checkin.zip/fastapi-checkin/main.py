# main.py
from fastapi import FastAPI, HTTPException, Query, Form, UploadFile, File

from fastapi.responses import HTMLResponse,RedirectResponse,StreamingResponse
from pydantic import BaseModel, Field
from psycopg_pool import ConnectionPool
from psycopg.rows import dict_row
import redis
import os
from dotenv import load_dotenv
from typing import Optional,Dict
from fastapi.middleware.cors import CORSMiddleware
import csv
import io 

load_dotenv()

REGISTRATION_OPEN = True          # 全局开关，可通过 /admin/open|close 修改

app = FastAPI(title="CheckIn")

# ===== CORS 允许前端 localhost =====
origins = [
    "http://localhost:3000",
    "http://localhost:3001",
    "http://139.224.133.69",
    "http://139.224.133.69:80"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- 数据库 ----------
DSN = os.getenv("DATABASE_URL")
pg_pool = ConnectionPool(conninfo=DSN, min_size=1, max_size=20,
                         kwargs={"row_factory": dict_row})

# ---------- Redis ----------
try:
    r = redis.from_url(os.getenv("REDIS_URL"), decode_responses=True)
    r.ping()
except Exception:
    r = None

# ---------- 模型 ----------
class CheckInRequest(BaseModel):
    reg_code: str

class CheckInResponse(BaseModel):
    status: str
    seat_number: Optional[str] = None
    table_number: Optional[str] = None
    verify_hash_code: Optional[str] = None
    lottery_code: Optional[int] = None  

# ==========================  唯一签到接口  ==========================
@app.post("/api/checkin", response_model=CheckInResponse)
def check_in(
    req: CheckInRequest,
    preview: int = Query(0, alias="preview")  # 0=正式签到 1=仅预览
):
    code = req.reg_code.strip()
    if not code.isdigit() or len(code) != 6:
        raise HTTPException(status_code=400, detail="注册码必须是 6 位数字")

    # 1. 缓存
    if r:
        cached = r.hgetall(f"reg:{code}")
        if cached and cached.get("signed") == "1":
            return CheckInResponse(
                status="already_signed",
                seat_number=cached.get("seat"),
                table_number=cached.get("table"),
                verify_hash_code=cached.get("vcode") or "",
                lottery_code=int(cached.get("lottery_code"))
            )

    # 2. 数据库
    with pg_pool.connection() as conn:
        row = conn.execute(
            "SELECT lottery_code, seat_number, table_number, is_signed, verify_hash_code "
            "FROM attendees WHERE reg_code = %s",
            (code,)
        ).fetchone()

    # --------- 决策核心 ---------
    if not row:  # 规则 2：注册码错误
        return CheckInResponse(status="not_found")

    if row["is_signed"]:  # 规则 1：已签到永远给座位
        if r:  # 补缓存
            r.hset(f"reg:{code}", mapping={
                "seat": row["seat_number"],
                "table": row["table_number"],
                "signed": "1",
                "vcode": row["verify_hash_code"] or "",
                "lottery_code": row["lottery_code"] 
            })
            r.expire(f"reg:{code}", 3600)
        return CheckInResponse(
            status="already_signed",
            seat_number=row["seat_number"],
            table_number=row["table_number"],
            verify_hash_code=row["verify_hash_code"],
            lottery_code=row["lottery_code"]
        )

    # 未签到且正确
    if not REGISTRATION_OPEN:  # 规则 4：开关关闭
        raise HTTPException(status_code=403, detail="Registration closed")

    if preview == 1:  # 规则 3：预览（开关已开）
        return CheckInResponse(
            status="found",
            seat_number=row["seat_number"],
            table_number=row["table_number"],
            verify_hash_code=row["verify_hash_code"],
            lottery_code=row["lottery_code"]
        )

    # 真正签到（开关已开）
    with pg_pool.connection() as conn:
        conn.execute(
            "UPDATE attendees SET is_signed = TRUE WHERE reg_code = %s",
            (code,)
        )
        conn.commit()
        if r:
            r.hset(f"reg:{code}", mapping={
                "seat": row["seat_number"],
                "table": row["table_number"],
                "signed": "1",
                "vcode": row["verify_hash_code"] or "",
                "lottery_code": row["lottery_code"] 
            })
            r.expire(f"reg:{code}", 3600)

    return CheckInResponse(
        status="found",
        seat_number=row["seat_number"],
        table_number=row["table_number"],
        verify_hash_code=row["verify_hash_code"],
        lottery_code=row["lottery_code"]
    )

# ==========================  管理员面板  ==========================
ADMIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
<style>
/* ====== 像素风基础 ====== */
*{
  box-sizing:border-box;
  image-rendering:pixelated;
  image-rendering:-moz-crisp-edges;
  image-rendering:crisp-edges;
  font-family:'Press Start 2P',SimSun,monospace;
  font-size:10px;
  color:#fde5a4;
}
body{
  margin:0;
  padding:20px;
  background:#6c9b2f;
  background-image:
    repeating-conic-gradient(#5a8228 0% 25%, #6c9b2f 0% 50%);
  background-size:32px 32px;
  box-shadow:inset 0 0 0 1px #4a6c20;
  min-height:100vh;
}
a{color:inherit;text-decoration:none;}

/* ====== 像素标题 & 状态灯 ====== */
.pixel-title{
  display:flex;
  align-items:center;
  gap:8px;
  font-size:50px;
  text-shadow:2px 2px 0 #5d2c0f;
  margin:0 0 20px;
}
/* 长方形像素状态条 */
.pixel-bar{
  display:inline-block;
  width:40px;          /* 长度 */
  height:20px;          /* 厚度 */
  margin-left:8px;
  border:2px solid #000;
  image-rendering:pixelated;
}
.pixel-bar.on {background:#3aff00;}
.pixel-bar.off{background:#ff3030;}


/* ====== 像素按钮 ====== */
.pixel-btn{
  display:inline-block;
  padding:6px 10px;
  margin:4px 4px 4px 0;
  background:#8b4513;
  border:4px solid #5d2c0f;
  box-shadow:0 0 0 2px #3e1e0a,2px 2px 0 #3e1e0a;
  cursor:pointer;
  transition:none;
}
.pixel-btn:hover{background:#6b8e23;}
.pixel-btn:active{transform:translate(2px,2px);box-shadow:none;}
.pixel-btn.danger{background:#b22222;}
.pixel-btn.danger:hover{background:#8b1a1a;}

/* ====== 像素卡片 ====== */
.pixel-card{
  background:#8b4513;
  border:6px solid #5d2c0f;
  box-shadow:0 0 0 2px #3e1e0a,4px 4px 8px rgba(0,0,0,.4);
  padding:12px;
  margin-bottom:16px;
}
.pixel-card h2{margin:0 0 8px;font-size:20px;text-shadow:1px 1px 0 #5d2c0f;}

/* ====== 表单元素 ====== */
.pixel-input{
  width:100%;
  padding:4px 6px;
  margin:4px 0;
  border:2px solid #5d2c0f;
  background:#fde5a4;
  color:#3e1e0a;
  font-size:10px;
}
</style>
</head>
<body>

<!-- 像素标题 + 状态灯 -->
<div class="pixel-title">
  管理员面板
</div>

<!-- 1. 全局开关 -->
<div class="pixel-card">
  <h2>注册控制器开关
    <!-- 长方形状态条 -->
    <span class="pixel-bar {{ LIGHT_CLASS }}"></span>
  </h2>

  <form action="/admin/open" method="post" onsubmit="return confirm('Open registration?')">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn">Open</button>
  </form>
  <form action="/admin/close" method="post" onsubmit="return confirm('Close registration?')">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn danger">Close</button>
  </form>
</div>

<!-- 2. 批量查询 -->
<div class="pixel-card">
  <h2>批量查询</h2>
  <form action="/admin/query_all" method="post">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn">全表查询</button>
  </form>
  <form action="/admin/query_remaining" method="post">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn">查询剩余</button>
  </form>
  <h2>高级查询（不过滤原接口）</h2>
  <form action="/admin/v2/query_all" method="post">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn">全表高级查询</button>
  </form>
  <form action="/admin/v2/winners" method="post">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn">中奖名单高级查询</button>
  </form>
</div>

<!-- 3. 单查 -->
<div class="pixel-card">
  <h2> 单独查询 </h2>
  <form action="/admin/query" method="post">
    <input type="hidden" name="password" value="admin123">
    <input class="pixel-input" type="number" name="lottery_code" placeholder="Lottery Code" required>
    <button class="pixel-btn">Query</button>
  </form>
</div>

<!-- 中奖名单 -->
<div class="pixel-card">
  <h2>查看中奖名单</h2>
  <form action="/admin/winners" method="post">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn" type="submit">查看中奖名单</button>
  </form>
</div>

<!-- 4. 添加用户 -->
<div class="pixel-card">
  <h2>手动添加用户</h2>
  <form action="/admin/add" method="post">
    <input type="hidden" name="password" value="admin123">
    <input class="pixel-input" type="text" name="reg_code" placeholder="6-digit Reg Code" required>
    <input class="pixel-input" type="text" name="seat_number" placeholder="Seat Number" required>
    <input class="pixel-input" type="text" name="table_number" placeholder="Table Number" required>
    <input class="pixel-input" type="text" name="verify_hash_code" placeholder="4-digit Verify (opt)">
    <button class="pixel-btn">Add</button>
  </form>
</div>

<!-- 5. 修改用户 -->
<div class="pixel-card">
  <h2>手动修改用户</h2>
  <form action="/admin/update" method="post">
    <input type="hidden" name="password" value="admin123">
    <input class="pixel-input" type="number" name="lottery_code" placeholder="Lottery Code" required>
    <input class="pixel-input" type="text" name="seat_number" placeholder="New Seat">
    <input class="pixel-input" type="text" name="table_number" placeholder="New Table">
    <input class="pixel-input" type="number" name="is_signed" placeholder="Signed? 0/1" min="0" max="1">
    <button class="pixel-btn">Update</button>
  </form>
</div>

<!-- 6. 删除用户 -->
<div class="pixel-card">
  <h2>删除用户</h2>
  <form action="/admin/delete" method="post" onsubmit="return confirm('Delete this record?')">
    <input type="hidden" name="password" value="admin123">
    <input class="pixel-input" type="number" name="lottery_code" placeholder="Lottery Code" required>
    <button class="pixel-btn danger">Delete</button>
  </form>
</div>

<!-- 7. 危险操作 -->
<div class="pixel-card">
  <h2>Danger Zone</h2>
  <form action="/admin/truncate" method="post" onsubmit="return confirm('Delete ALL records?')">
    <input type="hidden" name="password" value="admin123">
    <button class="pixel-btn danger">Delete All</button>
  </form>
</div>

<!-- 8. CSV 上传 -->
<div class="pixel-card">
  <h2>批量上传用户</h2>
  <form action="/admin/upload_csv" method="post" enctype="multipart/form-data">
    <input type="hidden" name="password" value="admin123">
    <input class="pixel-input" type="file" name="file" accept=".csv" required>
    <button class="pixel-btn">Upload</button>
  </form>
  <p style="margin:4px 0 0;font-size:8px;">CSV: reg_code,seat_number,table_number,verify_hash_code</p>
</div>

</body>
</html>
"""

@app.get("/admin", response_class=HTMLResponse)
def admin_page(password: str = ""):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    # 决定颜色
    light_class = "open" if REGISTRATION_OPEN else "closed"
    html = ADMIN_HTML.replace("{{ LIGHT_CLASS }}", "on" if REGISTRATION_OPEN else "off")
    # html = ADMIN_HTML.replace("{{ LIGHT_CLASS }}", light_class)
    return HTMLResponse(html)


# ==========================  管理员接口  ==========================
@app.post("/admin/query_all", response_class=HTMLResponse)
def admin_query_all(password: str = Form(...)):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    with pg_pool.connection() as conn:
        rows = conn.execute(
            "SELECT lottery_code, reg_code, seat_number, table_number, is_signed, verify_hash_code, result, claim_status, special_claim_status "
            "FROM attendees ORDER BY lottery_code"
        ).fetchall()
    return _render_table(rows, "全部人员")


@app.post("/admin/query_remaining", response_class=HTMLResponse)
def admin_query_remaining(password: str = Form(...)):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    with pg_pool.connection() as conn:
        rows = conn.execute(
            "SELECT lottery_code, reg_code, seat_number, table_number, is_signed, verify_hash_code, result, claim_status, special_claim_status  "
            "FROM attendees WHERE is_signed = FALSE ORDER BY lottery_code"
        ).fetchall()
    return _render_table(rows, "剩余未签到人员")


@app.post("/admin/query", response_class=HTMLResponse)
def admin_query(password: str = Form(...), lottery_code: int = Form(...)):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    with pg_pool.connection() as conn:
        row = conn.execute(
            "SELECT lottery_code, reg_code, seat_number, table_number, is_signed, verify_hash_code, result, claim_status, special_claim_status "
            "FROM attendees WHERE lottery_code = %s",
            (lottery_code,)
        ).fetchone()
    if not row:
        return HTMLResponse("<p>未找到该抽奖码</p>")
    return _render_table([row], "单查结果")


def _render_table(rows, title: str) -> str:
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>{title}</title>
        <style>
            body{{font-family:Arial;margin:20px;}}
            table{{border-collapse:collapse;width:100%;}}
            th,td{{border:1px solid #ddd;padding:8px;text-align:left;}}
            th{{background:#f2f2f2;}}
            a{{margin:10px 0;display:inline-block;}}
        </style>
    </head>
    <body>
        <h1>{title}</h1>
        <a href="/admin?password=admin123">返回管理员面板</a>
        <table>
            <tr>
                <th>抽奖码</th>
                <th>注册码</th>
                <th>桌号</th>
                <th>座位号</th>
                <th>已签到</th>
                <th>4 位验证码</th>
                <th>中奖结果</th>
                <th>普通奖项领取状态</th>
                <th>特殊奖项领取状态</th>
            </tr>
    """
    for r in rows:
        html += f"""
            <tr>
                <td>{r['lottery_code']}</td>
                <td>{r['reg_code']}</td>
                <td>{r['table_number']}</td>
                <td>{r['seat_number'] or ''}</td>
                <td>{'是' if r['is_signed'] else '否'}</td>
                <td>{r['verify_hash_code'] or ''}</td>
                <td>{r['result'] or ''}</td>
                <td>{'是' if r.get('claim_status') else '否'}</td>
                <td>{'是' if r.get('special_claim_status') else '否'}</td>
            </tr>
        """
    html += "</table></body></html>"
    return HTMLResponse(html)

@app.post("/admin/winners", response_class=HTMLResponse)
def admin_winners(password: str = Form(...)):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)

    with pg_pool.connection() as conn:
        rows = conn.execute(
            "SELECT lottery_code, reg_code, seat_number, table_number, is_signed, verify_hash_code, result, claim_status, special_claim_status "
            "FROM attendees WHERE result IS NOT NULL ORDER BY lottery_code"
        ).fetchall()

    if not rows:
        return HTMLResponse("<h2>暂无中奖人员</h2><a href='/admin?password=admin123'>返回面板</a>")

    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>中奖名单</title>
        <style>
            body{font-family:Arial;margin:20px;}
            table{border-collapse:collapse;width:100%;}
            th,td{border:1px solid #ddd;padding:8px;text-align:left;}
            th{background:#f2f2f2;}
            a{margin:10px 0;display:inline-block;}
        </style>
    </head>
    <body>
        <h1>中奖名单</h1>
        <a href="/admin?password=admin123">返回管理员面板</a>
        <table>
            <tr>
                <th>抽奖码</th>
                <th>注册码</th>
                <th>桌号</th>
                <th>已签到</th>
                <th>4 位验证码</th>
                <th>中奖结果</th>
                <th>普通奖项领取状态</th>
                <th>特殊奖项领取状态</th>
            </tr>
    """
    for r in rows:
        html += f"""
            <tr>
                <td>{r['lottery_code']}</td>
                <td>{r['reg_code']}</td>
                <td>{r['table_number'] or ''}</td>
                <td>{'是' if r['is_signed'] else '否'}</td>
                <td>{r['verify_hash_code'] or ''}</td>
                <td>{r['result'] or ''}</td>
                <td>{'是' if r.get('claim_status') else '否'}</td>
                <td>{'是' if r.get('special_claim_status') else '否'}</td>
            </tr>
        """   
    html += "</table></body></html>"
    return HTMLResponse(html)


@app.post("/admin/add")
def admin_add(password: str = Form(...),
              reg_code: str = Form(...),
              seat_number: str = Form(...),
              table_number: str = Form(...),
              verify_hash_code: str = Form("")):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    vcode = _check_vcode(verify_hash_code)
    rcode = _check_reg_code(reg_code)
    with pg_pool.connection() as conn:
        cur = conn.execute(
            "INSERT INTO attendees (reg_code, verify_hash_code, seat_number, table_number, is_signed) "
            "VALUES (%s, %s, %s, %s, FALSE) RETURNING lottery_code",
            (rcode, vcode, seat_number, table_number)
        )
        new_id = cur.fetchone()["lottery_code"]
        conn.commit()
    return {"message": "Added", "lottery_code": new_id}


@app.post("/admin/update")
def admin_update(
    password: str = Form(...),
    lottery_code: int = Form(...),
    seat_number: str = Form(""),
    table_number: str = Form(""),
    is_signed: int = Form(None),  # 先按整数接
    result: str = Form(""),
    claim_status: bool = Form(None),
    special_claim_status: bool = Form(None)
):

    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")

    updates, params = [], []
    if seat_number:
        updates.append("seat_number = %s")
        params.append(seat_number)
    if table_number:
        updates.append("table_number = %s")
        params.append(table_number)
    if is_signed is not None:
        updates.append("is_signed = %s")
        # 关键：转布尔
        params.append(bool(is_signed))
    if result.strip():          
        updates.append("result = %s")
        params.append(result.strip())
    if claim_status is not None:
        updates.append("claim_status = %s")
        params.append(bool(claim_status))
    if special_claim_status is not None:
        updates.append("special_claim_status = %s")
        params.append(bool(special_claim_status))

    if not updates:
        return {"message": "No updates"}

    params.append(lottery_code)
    with pg_pool.connection() as conn:
        conn.execute(
            f"UPDATE attendees SET {', '.join(updates)} WHERE lottery_code = %s",
            params
        )
        conn.commit()
    return {"message": "Updated"}


# @app.post("/admin/delete")
# def admin_delete(password: str = Form(...), lottery_code: int = Form(...)):
#     if password != "admin123":
#         raise HTTPException(status_code=403, detail="Access Denied")
#     with pg_pool.connection() as conn:
#         conn.execute("DELETE FROM attendees WHERE lottery_code = %s", (lottery_code,))
#         conn.commit()
#     return {"message": "Deleted"}

@app.post("/admin/delete")
def admin_delete(password: str = Form(...), lottery_code: int = Form(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")

    with pg_pool.connection() as conn:
        # 先拿到 reg_code，方便清缓存
        row = conn.execute(
            "SELECT reg_code FROM attendees WHERE lottery_code = %s",
            (lottery_code,)
        ).fetchone()
        if not row:
            return {"message": "Lottery code not found"}

        reg_code = row["reg_code"]

        # 真正删除
        conn.execute("DELETE FROM attendees WHERE lottery_code = %s", (lottery_code,))
        conn.commit()

    # 清缓存
    if r:
        r.delete(f"reg:{reg_code}")

    return {"message": "Deleted"}

@app.post("/admin/upload_csv")
def admin_upload_csv(password: str = Form(...), file: UploadFile = File(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files allowed")
    content = file.file.read().decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(content))
    inserted = updated = 0
    with pg_pool.connection() as conn:
        for row in reader:
            rco = row.get("reg_code", "").strip()
            if not rco:
                continue
            rcode = _check_reg_code(rco)
            vcode = _check_vcode(row.get("verify_hash_code", ""))
            data = {"verify_hash_code": vcode}
            for k, v in row.items():
                if k in ("reg_code", "verify_hash_code"):
                    continue
                if k == "is_signed":
                    data[k] = v.strip().lower() in ("true", "1", "yes")
                else:
                    data[k] = v.strip() if v else None
            existing = conn.execute(
                "SELECT 1 FROM attendees WHERE reg_code = %s", (rcode,)
            ).fetchone()
            if existing:
                if data:
                    set_parts = [f"{k} = %s" for k in data.keys()]
                    values = list(data.values()) + [rcode]
                    conn.execute(
                        f"UPDATE attendees SET {', '.join(set_parts)} WHERE reg_code = %s",
                        values
                    )
                updated += 1
            else:
                cols = ["reg_code"] + list(data.keys())
                placeholders = ", ".join(["%s"] * len(cols))
                values = [rcode] + list(data.values())
                conn.execute(
                    f"INSERT INTO attendees ({', '.join(cols)}) VALUES ({placeholders})",
                    values
                )
                inserted += 1
        conn.commit()
    return {"message": f"Processed: {inserted} inserted, {updated} updated"}


# ---------- 开关注册 & 清空 ----------
@app.post("/admin/open")
def open_registration(password: str = Form(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    global REGISTRATION_OPEN
    REGISTRATION_OPEN = True
    return RedirectResponse(url="/admin?password=admin123", status_code=302)


@app.post("/admin/close")
def close_registration(password: str = Form(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    global REGISTRATION_OPEN
    REGISTRATION_OPEN = False
    return RedirectResponse(url="/admin?password=admin123", status_code=302)


@app.post("/admin/truncate")
def truncate_all(password: str = Form(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    with pg_pool.connection() as conn:
        conn.execute("TRUNCATE TABLE attendees RESTART IDENTITY CASCADE")
        conn.commit()
    if r:
        for key in r.scan_iter("reg:*"):
            r.delete(key)
    return {"message": "All attendees deleted"}

@app.get("/api/status")
def reg_status():
    return {"registration_open": REGISTRATION_OPEN}

# ---------- 工具 ----------
def _check_reg_code(r: str) -> str:
    r = r.strip()
    if not r.isdigit() or len(r) != 6:
        raise HTTPException(status_code=400, detail="reg_code must be 6 digits")
    return r

def _check_vcode(v: Optional[str]) -> Optional[str]:
    if not v or v.strip() == "":
        return None
    v = v.strip()
    if not v.isdigit() or len(v) != 4:
        raise HTTPException(status_code=400, detail="verify_hash_code must be 4 digits")
    return v

# ---------- 模型 ----------
class AwardRequest(BaseModel):
    lottery_code: int = Field(..., coerce=True)   # 允许字符串转整数


# ---------- 1. 发「阳光普照」通用奖 ----------
@app.post("/api/award/sunshine")
def award_sunshine(req: AwardRequest):
    """
    把 general_award 列更新为「阳光普照」
    """
    with pg_pool.connection() as conn:
        cur = conn.execute(
            "UPDATE attendees SET general_award = '阳光普照' "
            "WHERE lottery_code = %s RETURNING lottery_code",
            (req.lottery_code,)
        )
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Lottery code not found")
        conn.commit()
    return {"message": "General award granted", "award": "阳光普照"}

# ---------- 普通领奖 ----------
@app.post("/api/award/claim", response_model=bool)
def award_claim(req: AwardRequest) -> bool:
    """
    已签到且未领取过普通奖 → 领取成功返回 True
    如果对应 seat_number == 'ffff'，直接返回 False
    """
    with pg_pool.connection() as conn:
        row = conn.execute(
            "SELECT seat_number, is_signed, claim_status FROM attendees "
            "WHERE lottery_code = %s FOR UPDATE",
            (req.lottery_code,)
        ).fetchone()
        if not row:
            return False

        # 关键：seat_number 为 ffff 立即拒绝
        if row["seat_number"] == "ffff":
            return False

        if not row["is_signed"] or row["claim_status"]:
            return False

        conn.execute(
            "UPDATE attendees SET claim_status = TRUE "
            "WHERE lottery_code = %s",
            (req.lottery_code,)
        )
        conn.commit()
        return True


# ---------- 特殊领奖 ----------
@app.post("/api/award/special-claim", response_model=bool)
def award_special_claim(req: AwardRequest) -> bool:
    """
    已签到 && 未领取过特殊奖 && result 非空 → 领取成功返回 True
    """
    with pg_pool.connection() as conn:
        row = conn.execute(
            "SELECT is_signed, special_claim_status, result "
            "FROM attendees "
            "WHERE lottery_code = %s "
            "FOR UPDATE",
            (req.lottery_code,)
        ).fetchone()
        if not row:
            return False
        # 核心：result 为空表示没中奖，直接拒绝
        if row["result"] is None:
            return False
        if not row["is_signed"] or row["special_claim_status"]:
            return False

        conn.execute(
            "UPDATE attendees SET special_claim_status = TRUE "
            "WHERE lottery_code = %s",
            (req.lottery_code,)
        )
        conn.commit()
        return True


# 新增独立接口文件尾部即可

# 1. 全表高级查询
@app.post("/admin/v2/query_all")
def admin_v2_query_all(
        password: str = Form(...),
        export: int = Query(0, alias="export"),
        lottery_code: Optional[str] = Form(""),
        reg_code: Optional[str] = Form(""),
        table_number: Optional[str] = Form(""),
        seat_number: Optional[str] = Form(""),
        is_signed: Optional[str] = Form(""),
        verify_hash_code: Optional[str] = Form(""),
        result: Optional[str] = Form(""),
        claim_status: Optional[str] = Form(""),
        special_claim_status: Optional[str] = Form("")
):
    # 把局部变量打包成原 filters 字典
    filters = {
        "lottery_code": lottery_code,
        "reg_code": reg_code,
        "table_number": table_number,
        "seat_number": seat_number,
        "is_signed": is_signed,
        "verify_hash_code": verify_hash_code,
        "result": result,
        "claim_status": claim_status,
        "special_claim_status": special_claim_status
    }
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)

    where, params = _v2_build_filter(filters)
    sql = (f"SELECT lottery_code, reg_code, seat_number, table_number, is_signed, verify_hash_code, result, claim_status, special_claim_status "
           f"FROM attendees {where} ORDER BY lottery_code")
    with pg_pool.connection() as conn:
        rows = conn.execute(sql, params).fetchall()

    if export:
        return _v2_csv_response(rows, filename="filtered_attendees.csv")
    return _v2_render_datatable_front_filter(rows, "高级查询 (全列过滤)")


# 2. 中奖名单高级查询
@app.post("/admin/v2/winners")
def admin_v2_winners(
        password: str = Form(...),
        export: int = Query(0, alias="export"),
        lottery_code: Optional[str] = Form(""),
        reg_code: Optional[str] = Form(""),
        table_number: Optional[str] = Form(""),
        seat_number: Optional[str] = Form(""),
        is_signed: Optional[str] = Form(""),
        verify_hash_code: Optional[str] = Form(""),
        result: Optional[str] = Form(""),
        claim_status: Optional[str] = Form(""),
        special_claim_status: Optional[str] = Form("")
):
    filters = {
        "lottery_code": lottery_code,
        "reg_code": reg_code,
        "table_number": table_number,
        "seat_number": seat_number,
        "is_signed": is_signed,
        "verify_hash_code": verify_hash_code,
        "result": result,
        "claim_status": claim_status,
        "special_claim_status": special_claim_status
    }
    filters["result"] = "__notnull"  # 强制只查中奖
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)

    where, params = _v2_build_filter(filters)
    sql = (f"SELECT lottery_code, reg_code, seat_number, table_number, is_signed, verify_hash_code, result, claim_status, special_claim_status "
           f"FROM attendees {where} ORDER BY lottery_code")
    with pg_pool.connection() as conn:
        rows = conn.execute(sql, params).fetchall()

    if export:
        return _v2_csv_response(rows, filename="filtered_winners.csv")
    return _v2_render_datatable_front_filter(rows, "中奖名单（过滤版）")


# 3. 过滤器构造（同之前，复制一份命名 _v2 避免冲突）
def _v2_build_filter(filters: Dict[str, str]):
    conds, params = [], []
    for col, val in filters.items():
        val = val.strip()
        if not val:
            continue
        if val == "__null":
            conds.append(f"{col} IS NULL")
        elif val == "__notnull":
            conds.append(f"{col} IS NOT NULL")
        else:
            if col in {"lottery_code", "is_signed", "claim_status", "special_claim_status"}:
                conds.append(f"{col} = %s")
                params.append(val)
            else:
                conds.append(f"{col} ILIKE %s")
                params.append(f"%{val}%")
    where = "WHERE " + " AND ".join(conds) if conds else ""
    return where, params


# 4. CSV 流式导出
def _v2_csv_response(rows, filename: str):
    buf = io.StringIO()
    # 1. 写 UTF-8 BOM
    buf.write('\ufeff')
    # 2. 写表头
    w = csv.writer(buf)
    w.writerow(["抽奖码", "注册码", "桌号", "座位号", "已签到", "验证码", "中奖结果", "普通奖领取", "特殊奖领取"])
    # 3. 写数据
    for r in rows:
        w.writerow([
            r["lottery_code"], r["reg_code"],
            r["table_number"] or "", r["seat_number"] or "",
            "是" if r["is_signed"] else "否",
            r["verify_hash_code"] or "", r["result"] or "",
            "是" if r.get("claim_status") else "否",
            "是" if r.get("special_claim_status") else "否"
        ])
    buf.seek(0)
    return StreamingResponse(
        io.BytesIO(buf.getvalue().encode("utf-8")),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

def _v2_render_datatable_front_filter(rows, title: str):
    cols = [
        ("lottery_code", "抽奖码"),
        ("reg_code", "注册码"),
        ("table_number", "桌号"),
        ("seat_number", "座位号"),
        ("is_signed", "已签到"),
        ("verify_hash_code", "验证码"),
        ("result", "中奖结果"),
        ("claim_status", "普通奖领取"),
        ("special_claim_status", "特殊奖领取")
    ]

    # 构造 <tbody> 一次性输出
    tbody = []
    for r in rows:
        row = []
        for col, _ in cols:
            v = r.get(col, "") or ""
            if col in {"is_signed", "claim_status", "special_claim_status"}:
                v = "是" if v else "否"
            row.append(f"<td>{v}</td>")
        tbody.append("<tr>" + "".join(row) + "</tr>")

    thead = "".join(f"<th>{desc}</th>" for _, desc in cols)

    # 用 raw string 包裹 JS，避免 f-string 冲突
    js_code = r"""
    $(function(){
        let table = $('#dataTable').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csvHtml5',
                    text: 'Export to CSV',
                    className: 'pixel-btn',
                    exportOptions: { columns: ':visible' }
                }
            ],
            initComplete: function () {
                this.api().columns().every( function () {
                    let column = this;
                    let select = $('<select><option value=""></option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            let val = $.fn.dataTable.util.escapeRegex($(this).val());
                            column.search( val ? '^'+val+'$' : '', true, false ).draw();
                        });
                    column.data().unique().sort().each( function ( d ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' );
                    });
                    select.select2({width: '100%', placeholder: '筛选', allowClear: true});
                });
            }
        });
    });
    """

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>{title}</title>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css"/>
        <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css"/>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
        <style>
            body{{font-family:Arial,Helvetica,sans-serif;margin:20px;font-size:12px;}}
            .pixel-btn{{display:inline-block;padding:4px 8px;margin:4px 4px 4px 0;background:#8b4513;color:#fde5a4;border:2px solid #5d2c0f;cursor:pointer;font-size:10px;}}
            .dt-buttons{{margin-bottom:6px;}}
            tfoot th{{padding:2px !important;}}
            tfoot select{{width:100%;font-size:10px;}}
        </style>
    </head>
    <body>
        <h1>{title}</h1>
        <a href="/admin?password=admin123">返回管理员面板</a>
        <div class="dt-buttons"></div>

        <table id="dataTable" class="display" style="width:100%">
            <thead><tr>{thead}</tr></thead>
            <tbody>{"".join(tbody)}</tbody>
            <tfoot><tr>{"".join(f'<th></th>' for _ in cols)}</tr></tfoot>
        </table>

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script>{js_code}</script>
    </body>
    </html>
    """
    return HTMLResponse(html)