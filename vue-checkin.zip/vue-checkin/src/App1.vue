<template>
  <div class="check-in-wrapper">
    <!-- 背景层 -->
    <section class="mc-bg" :style="bgStyle">
      <!-- 金色✨容器 -->
      <div class="star-field" aria-hidden="true">
        <div
          v-for="s in stars"
          :key="s.id"
          class="pixel-star"
          :style="s.style"
        />
      </div>
    </section>

    <section class="box">
      <h2>2026 Annual Party Check-in</h2>
      <input
        v-model="code"
        type="text"
        inputmode="numeric"
        pattern="\d*"
        maxlength="6"
        placeholder="Enter 6-digit code"
      />
      <button @click="handleCheck" :disabled="checking">
        {{ checking ? 'Checking...' : 'Check' }}
      </button>

      <!-- 错误/未找到 -->
      <div v-if="preview && preview.status !== 'found' && preview.status !== 'already_signed'" class="result">
        <p v-if="preview.status === 'error'">Failed: {{ preview.message }}</p>
        <p v-else-if="preview.status === 'not_found'">
            Invalid registration code. Please contact the administrator or re-enter a valid 6-digit code.
        </p>
      </div>

      <!-- 永久展示区域（已签到或签到成功） -->
      <div v-if="finalInfo" class="final-box">
        <h3>Your Seat Info</h3>
        <p class="congrats">Congratulations! Your registration is complete.</p>
        <p class="tip">Please take a screenshot to save your seat information.</p>
        <p>Seat: <span>{{ finalInfo.seat_number }}</span></p>
        <p>Table: <span>{{ finalInfo.table_number }}</span></p>
      </div>
    </section>

    <!-- 像素风确认对话框 -->
    <div v-if="confirmDialog" class="modal-overlay" @click.self="cancelCheck">
      <div class="modal-box pixel">
        <p class="modal-text">
          Seat: {{ preview.seat_number }} &nbsp; Table: {{ preview.table_number }}<br>
          Your GPN last 4 digits are <strong>{{ verifyCode }}</strong>. If correct, please confirm check-in.
        </p>
        <div class="modal-buttons">
          <button class="yes pixel-btn" @click="confirmCheck">Yes</button>
          <button class="no pixel-btn" @click="cancelCheck">No</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const code = ref('')
const preview = ref(null)
const verifyCode = ref('')
const confirmDialog = ref(false)
const finalInfo = ref(null)
const checking = ref(false)

/* -------- 工具：调后端 -------- */
async function apiPreview(regCode) {
  const res = await fetch(`http://139.224.133.69/api/checkin?preview=1`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reg_code: regCode })
  })

  // 1. 注册码错误
  if (res.status === 404) return { status: 'not_found' }

  // 2. 注册关闭（未签到+开关关）
  if (res.status === 403) {
    throw new Error('Registration is closed. Please contact the administrator.')
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}


async function apiCheckIn(regCode) {
  const res = await fetch(`http://139.224.133.69/api/checkin?preview=0`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reg_code: regCode })
  })

  if (res.status === 404) {
    return { status: 'not_found' }
  }

  if (res.status === 403) {
    throw new Error('Registration is closed. Please contact the administrator.')
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}


/* -------- 第一次 Check：仅预览 -------- */
async function handleCheck() {
  if (code.value.length !== 6) {
    preview.value = { status: 'error', message: 'Please enter a 6-digit code.' }
    return
  }
  checking.value = true
  try {
    const res = await apiPreview(code.value)
    preview.value = res
    if (res.status === 'already_signed') {
      finalInfo.value = { seat_number: res.seat_number, table_number: res.table_number }
    } else if (res.status === 'found') {
      verifyCode.value = res.verify_hash_code?.slice(-4) || '0000'
      confirmDialog.value = true
    }
  } catch (e) {
    preview.value = { status: 'error', message: e.message }
  } finally {
    checking.value = false
  }
}

/* -------- 点 Yes：真正写库 -------- */
async function confirmCheck() {
  try {
    const res = await apiCheckIn(code.value)
    if (res.status === 'found' || res.status === 'already_signed') {
      finalInfo.value = { seat_number: res.seat_number, table_number: res.table_number }
    }
  } catch (e) {
    preview.value = { status: 'error', message: e.message }
  } finally {
    confirmDialog.value = false
  }
}

function cancelCheck() {
  confirmDialog.value = false
}

/* ===== 背景图 ===== */

const bgStyle = { background: 'url(/horse_bg.jpg) center/cover no-repeat' }


/* ===== 随机金色✨ ===== */
const stars = ref([])
onMounted(() => {
  for (let i = 0; i < 40; i++) {
    stars.value.push({
      id: i,
      style: {
        left: `${Math.random() * 100}%`,
        animationDuration: `${3 + Math.random() * 4}s`,
        animationDelay: `${Math.random() * 6}s`,
        '--scale': 1.5 + Math.random()
      }
    })
  }
})

</script>


<style scoped>
/* ===================== 像素风样式 ===================== */
* {
  font-family: "Courier New", SimSun, monospace;
  image-rendering: pixelated;
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
}

/* ---------- 背景层 ---------- */
/* ===================== 国际化鎏金深红背景 ===================== */
/* ===== 像素风金色马雨 ===== */
.mc-bg {
  position: fixed;
  inset: 0;
  z-index: 1;
  background: url(@/img/horse_bg.jpg) center/cover no-repeat;   /* 关键一句 */
  overflow: hidden;
}

.star-field {
  position: absolute;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
}

.pixel-star {
  position: absolute;
  width: 4px;
  height: 4px;
  background: #ffd700;
  /* 4×4 像素星 */
  box-shadow:
    1px 0 0 0 #ffd700,
    0 1px 0 0 #ffd700, 1px 1px 0 0 #fff, 2px 1px 0 0 #ffd700,
    1px 2px 0 0 #ffd700;
  animation: starFall linear infinite;
}

@keyframes starFall {
  to { transform: translateY(110vh) scale(var(--scale, 1)); }
}


/* ---------- 工作台 ---------- */
.check-in-wrapper {
  min-height: 100vh;
  display: flex;
  align-items: center;      /* 原来 flex-end → center */
  justify-content: center;
  padding-bottom: 0;        /* 去掉留空 */
}


.box {
  /* 去掉原来的 margin: 60px auto; */
  position: relative;
  z-index: 10;
  max-width: 320px;
  width: 100%;
  /* 其余原来样式不动 */
}


/* 1. placeholder 黑色描边（像素风） */
input::placeholder {
  color: #c7a252;
  font-weight: 700;
  opacity: 1;
  /* 上下左右各 1px 黑色描边 */
  text-shadow:
    -1px -1px 0 #000,
     1px -1px 0 #000,
    -1px  1px 0 #000,
     1px  1px 0 #000;
}

/* 2. 标题阴影背景（像素长条） */
h2 {
  position: relative;
  display: inline-block;
  padding: 4px 12px;
  color: #f3d58a;
  font-weight: 700;
  letter-spacing: 1px;
  /* 像素描边 */
  text-shadow:
    -1px -1px 0 #000,
     1px -1px 0 #000,
    -1px  1px 0 #000,
     1px  1px 0 #000;
}

/* 黑色像素背景条 */
h2::before {
  content: '';
  position: absolute;
  inset: 0;
  background: #000;
  z-index: -1;
  /* 像素外框 */
  box-shadow:
    0 0 0 2px #5d2c0f,
    0 0 0 4px #3e1e0a;
}


input {
  width: 100%;
  padding: 8px 4px;
  margin-bottom: 12px;
  font-size: 16px;
  font-weight: 700;                     /* 加粗 */
  color: #fde5a4;                 /* 文字用金色 */
  background: transparent;        /* 关键：完全透明 */
  border: none;                   /* 去掉默认边框 */
  border-bottom: 2px solid #ffd700; /* 仅留金色底线 */
  outline: none;
  box-sizing: border-box;
}
/* 聚焦时底线高亮 */
input:focus {
  border-bottom-color: #ffec8b;
}
button {
  width: 100%;
  padding: 8px 0;
  font-size: 16px;
  background: #6b8e23;
  color: #fff;
  border: 2px solid #5d2c0f;
  cursor: pointer;
}
button:hover {
  background: linear-gradient(135deg, #ffd700 0%, #ffec8b 50%, #ffd700 100%);
  color: #6b0000;
  transition: all 0.25s;
}
button:active { transform: translateY(2px); }
.result {
  margin-top: 15px;
  color: #fde5a4;
  font-weight: bold;
  text-shadow: 1px 1px 0 #5d2c0f;
}

/* ---------- 确认对话框 ---------- */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.55);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}
.modal-box.pixel {
  background: #8b4513;
  border: 6px solid #5d2c0f;
  box-shadow: 0 0 0 2px #3e1e0a, 0 0 25px rgba(0,0,0,.7);
  padding: 25px 30px;
  max-width: 400px;
  text-align: center;
  color: #fde5a4;
}
.modal-text {
  margin: 0 0 20px;
  font-size: 16px;
  line-height: 1.5;
}
.modal-buttons {
  display: flex;
  gap: 15px;
  justify-content: center;
}
.pixel-btn {
  flex: 1;
  padding: 8px 0;
  font-size: 16px;
  border: 2px solid #5d2c0f;
  cursor: pointer;
  color: #fff;
}
.pixel-btn.yes { background: #6b8e23; }
.pixel-btn.yes:hover { background: #556b2f; }
.pixel-btn.no  { background: #b22222; }
.pixel-btn.no:hover  { background: #8b1a1a; }

/* ---------- 永久信息展示框 ---------- */
.final-box .congrats {
  margin: 0 0 4px;
  font-weight: bold;
  color: #5d2c0f;
}
.final-box .tip {
  margin: 0 0 12px;
  font-size: 14px;
  color: #6b8e23;
}

</style>
