<template>
  <div class="check-in-wrapper">
    <section class="mc-bg"><div class="horse-line"></div></section>

    <section class="box">
      <h2>2026 Conference Check-in</h2>
      <input
        v-model="code"
        type="text"
        inputmode="numeric"
        pattern="\d*"
        maxlength="6"
        placeholder="Enter 6-digit code"
      />
      <button @click="handleCheck" :disabled="checking">
        {{ checking ? 'Checking...' : 'Check' }}
      </button>

      <!-- 错误/未找到 -->
      <div v-if="preview && preview.status !== 'found' && preview.status !== 'already_signed'" class="result">
        <p v-if="preview.status === 'error'">Failed: {{ preview.message }}</p>
        <p v-else-if="preview.status === 'not_found'">
            Invalid registration code. Please contact the administrator or re-enter a valid 6-digit code.
        </p>
      </div>

      <!-- 永久展示区域（已签到或签到成功） -->
      <div v-if="finalInfo" class="final-box">
        <h3>Your Seat Info</h3>
        <p class="congrats">Congratulations! Your registration is complete.</p>
        <p class="tip">Please take a screenshot to save your seat information.</p>
        <p>Seat: <span>{{ finalInfo.seat_number }}</span></p>
        <p>Table: <span>{{ finalInfo.table_number }}</span></p>
      </div>
    </section>

    <!-- 像素风确认对话框 -->
    <div v-if="confirmDialog" class="modal-overlay" @click.self="cancelCheck">
      <div class="modal-box pixel">
        <p class="modal-text">
          Seat: {{ preview.seat_number }} &nbsp; Table: {{ preview.table_number }}<br>
          Your GPN last 4 digits are <strong>{{ verifyCode }}</strong>. If correct, please confirm check-in.
        </p>
        <div class="modal-buttons">
          <button class="yes pixel-btn" @click="confirmCheck">Yes</button>
          <button class="no pixel-btn" @click="cancelCheck">No</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const code = ref('')
const preview = ref(null)
const verifyCode = ref('')
const confirmDialog = ref(false)
const finalInfo = ref(null)
const checking = ref(false)

/* -------- 工具：调后端 -------- */
async function apiPreview(regCode) {
  const res = await fetch(`http://139.224.133.69/api/checkin?preview=1`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reg_code: regCode })
  })

  // 1. 注册码错误
  if (res.status === 404) return { status: 'not_found' }

  // 2. 注册关闭（未签到+开关关）
  if (res.status === 403) {
    throw new Error('Registration is closed. Please contact the administrator.')
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}


async function apiCheckIn(regCode) {
  const res = await fetch(`http://139.224.133.69/api/checkin?preview=0`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reg_code: regCode })
  })

  if (res.status === 404) {
    return { status: 'not_found' }
  }

  if (res.status === 403) {
    throw new Error('Registration is closed. Please contact the administrator.')
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}


/* -------- 第一次 Check：仅预览 -------- */
async function handleCheck() {
  if (code.value.length !== 6) {
    preview.value = { status: 'error', message: 'Please enter a 6-digit code.' }
    return
  }
  checking.value = true
  try {
    const res = await apiPreview(code.value)
    preview.value = res
    if (res.status === 'already_signed') {
      finalInfo.value = { seat_number: res.seat_number, table_number: res.table_number }
    } else if (res.status === 'found') {
      verifyCode.value = res.verify_hash_code?.slice(-4) || '0000'
      confirmDialog.value = true
    }
  } catch (e) {
    preview.value = { status: 'error', message: e.message }
  } finally {
    checking.value = false
  }
}

/* -------- 点 Yes：真正写库 -------- */
async function confirmCheck() {
  try {
    const res = await apiCheckIn(code.value)
    if (res.status === 'found' || res.status === 'already_signed') {
      finalInfo.value = { seat_number: res.seat_number, table_number: res.table_number }
    }
  } catch (e) {
    preview.value = { status: 'error', message: e.message }
  } finally {
    confirmDialog.value = false
  }
}

function cancelCheck() {
  confirmDialog.value = false
}
</script>


<style scoped>
/* ===================== 像素风样式 ===================== */
* {
  font-family: "Courier New", SimSun, monospace;
  image-rendering: pixelated;
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
}

/* ---------- 背景层 ---------- */
.mc-bg {
  position: fixed;
  inset: 0;
  overflow: hidden;
  background: 0 0 / 32px 32px
              repeating-conic-gradient(#6c9b2f 0% 25%, #5a8228 0% 50%);
  box-shadow: inset 0 0 0 1px #4a6c20;
  z-index: 1;
}
.horse-line {
  position: absolute;
  bottom: 20%;
  display: flex;
  width: 200vw;
  animation: march 8s linear infinite;
}
.horse-line::before,
.horse-line::after {
  content: '';
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-around;
  font-size: 3rem;
  color: #8B4513;
}
.horse-line::before { content: '🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎';}

.horse-line::after  { content: '🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎'; }
@keyframes march { to { transform: translateX(-100vw); } }

/* ---------- 工作台 ---------- */
.box {
  position: relative;
  z-index: 10;
  max-width: 320px;
  margin: 60px auto;
  text-align: center;
  background: #8b4513;
  border: 6px solid #5d2c0f;
  box-shadow: 0 0 0 2px #3e1e0a, 0 0 20px rgba(0, 0, 0, .6);
  padding: 20px;
}
h2 {
  margin: 0 0 20px;
  color: #fde5a4;
  text-shadow: 2px 2px 0 #5d2c0f;
  letter-spacing: 1px;
}
input {
  width: 100%;
  padding: 8px 12px;
  margin-bottom: 12px;
  font-size: 16px;
  border: 2px solid #5d2c0f;
  background: #fde5a4;
  color: #3e1e0a;
  outline: none;
  box-sizing: border-box;
}
button {
  width: 100%;
  padding: 8px 0;
  font-size: 16px;
  background: #6b8e23;
  color: #fff;
  border: 2px solid #5d2c0f;
  cursor: pointer;
}
button:hover { background: #556b2f; }
button:active { transform: translateY(2px); }
.result {
  margin-top: 15px;
  color: #fde5a4;
  font-weight: bold;
  text-shadow: 1px 1px 0 #5d2c0f;
}

/* ---------- 确认对话框 ---------- */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.55);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}
.modal-box.pixel {
  background: #8b4513;
  border: 6px solid #5d2c0f;
  box-shadow: 0 0 0 2px #3e1e0a, 0 0 25px rgba(0,0,0,.7);
  padding: 25px 30px;
  max-width: 400px;
  text-align: center;
  color: #fde5a4;
}
.modal-text {
  margin: 0 0 20px;
  font-size: 16px;
  line-height: 1.5;
}
.modal-buttons {
  display: flex;
  gap: 15px;
  justify-content: center;
}
.pixel-btn {
  flex: 1;
  padding: 8px 0;
  font-size: 16px;
  border: 2px solid #5d2c0f;
  cursor: pointer;
  color: #fff;
}
.pixel-btn.yes { background: #6b8e23; }
.pixel-btn.yes:hover { background: #556b2f; }
.pixel-btn.no  { background: #b22222; }
.pixel-btn.no:hover  { background: #8b1a1a; }

/* ---------- 永久信息展示框 ---------- */
.final-box .congrats {
  margin: 0 0 4px;
  font-weight: bold;
  color: #5d2c0f;
}
.final-box .tip {
  margin: 0 0 12px;
  font-size: 14px;
  color: #6b8e23;
}

</style>
