<template>
  <div class="check-in-wrapper">
    <!-- 背景层 -->
    <section class="mc-bg" :style="bgStyle">
      <!-- 金色✨容器 -->
      <div class="star-field" aria-hidden="true">
        <div
          v-for="s in stars"
          :key="s.id"
          class="pixel-star"
          :style="s.style"
        />
      </div>
    </section>

    <section class="box">
      <h2>2026 Annual Party Check-in</h2>
      <input
        v-model="code"
        type="text"
        inputmode="numeric"
        pattern="\d*"
        maxlength="6"
        placeholder="Enter 6-digit code"
      />
      <button @click="handleCheck" :disabled="checking">
        {{ checking ? 'Checking...' : 'Check' }}
      </button>

      <!-- 错误/未找到 -->
      <div v-if="preview && preview.status !== 'found' && preview.status !== 'already_signed'" class="result">
        <p v-if="preview.status === 'error'">Failed: {{ preview.message }}</p>
        <p v-else-if="preview.status === 'not_found'">
            Invalid registration code. Please contact the administrator or re-enter a valid 6-digit code.
        </p>
      </div>

      <!-- 永久展示区域（已签到或签到成功） -->
      <div v-if="finalInfo" class="final-box">
        <h3>Check-in Complete</h3>
        <p class="info">Table: {{ finalInfo.table_number }}</p>
        <p class="info">Lottery Code: {{ finalInfo.lottery_code }}</p>
        <qrcode-vue3
          :value="String(finalInfo.lottery_code)"
          :width="120"
          :height="120"
        />
        <p class="tip">Screenshot saved for entry</p>
      </div>

    </section>

    <!-- seat=ffff 提示框 -->
      <div v-if="seatTip" class="modal-overlay" @click.self="seatTip = false">
        <div class="modal-box pixel">
          <p class="modal-text">
            您无需参与领取阳光普照奖<br>
            You are not eligible for the Sunshine Participation Award.
          </p>
          <div class="modal-buttons">
            <button class="pixel-btn yes" @click="seatTip = false">OK</button>
          </div>
        </div>
      </div>

    <!-- 像素风确认对话框 -->
    <div v-if="confirmDialog" class="modal-overlay" @click.self="cancelCheck">
      <div class="modal-box pixel">
        <p class="modal-text">
          Table: {{ preview.table_number }}<br>
          Your GPN last 4 digits are <strong>{{ verifyCode }}</strong>. If correct, please confirm check-in.
        </p>
        <div class="modal-buttons">
          <button class="yes pixel-btn" @click="confirmCheck">Yes</button>
          <button class="no pixel-btn" @click="cancelCheck">No</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import QrcodeVue3 from 'qrcode-vue3'

const code = ref('')
const preview = ref(null)
const verifyCode = ref('')
const confirmDialog = ref(false)
const finalInfo = ref(null)
const checking = ref(false)
const seatTip = ref(false) 

/* -------- 工具：调后端 -------- */
async function apiPreview(regCode) {
  const res = await fetch(`http://139.224.133.69/api/checkin?preview=1`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reg_code: regCode })
  })

  // 1. 注册码错误
  if (res.status === 404) return { status: 'not_found' }

  // 2. 注册关闭（未签到+开关关）
  if (res.status === 403) {
    throw new Error('Registration is closed. Please contact the administrator.')
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}


async function apiCheckIn(regCode) {
  const res = await fetch(`http://139.224.133.69/api/checkin?preview=0`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reg_code: regCode })
  })

  if (res.status === 404) {
    return { status: 'not_found' }
  }

  if (res.status === 403) {
    throw new Error('Registration is closed. Please contact the administrator.')
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}


/* -------- 第一次 Check:仅预览 -------- */
async function handleCheck() {
  if (code.value.length !== 6) {
    preview.value = { status: 'error', message: 'Please enter a 6-digit code.' }
    return
  }
  checking.value = true
  try {
    const res = await apiPreview(code.value)
    preview.value = res
    if (res.status === 'already_signed') {
      finalInfo.value = { lottery_code: res.lottery_code, table_number: res.table_number }
    } else if (res.status === 'found') {
      verifyCode.value = res.verify_hash_code?.slice(-4) || '0000'
      confirmDialog.value = true
    }
  } catch (e) {
    preview.value = { status: 'error', message: e.message }
  } finally {
    checking.value = false
  }
}

/* -------- 点 Yes:真正写库 -------- */
async function confirmCheck() {
  try {
    const res = await apiCheckIn(code.value)
    if (res.status === 'found' || res.status === 'already_signed') {
      // 1. 发阳光普照奖（后台自行过滤，前端仅提示）
      await fetch('http://139.224.133.69/api/award/sunshine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lottery_code: res.lottery_code })
      })

      // 2. 写最终信息（二维码照常渲染）
      finalInfo.value = {
        table_number: res.table_number,
        lottery_code: res.lottery_code,
        seat_number: res.seat_number   // ← 新增，后面也要展示
      }

      // 3. seat_number 为 ffff 时弹出提示
      if (res.seat_number === 'ffff') {
        seatTip.value = true
      }
    }
  } catch (e) {
    preview.value = { status: 'error', message: e.message }
  } finally {
    confirmDialog.value = false
  }
}

function cancelCheck() {
  confirmDialog.value = false
}

/* ===== 背景图 ===== */
const bgStyle = { background: 'url(/horse_bg.jpg) center/cover no-repeat' }


/* ===== 随机金色✨ ===== */
const stars = ref([])
onMounted(() => {
  for (let i = 0; i < 40; i++) {
    stars.value.push({
      id: i,
      style: {
        left: `${Math.random() * 100}%`,
        animationDuration: `${3 + Math.random() * 4}s`,
        animationDelay: `${Math.random() * 6}s`,
        '--scale': 1.5 + Math.random()
      }
    })
  }
})

</script>


<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Germania+One&display=swap');
/* ===================== 像素风样式 ===================== */
* {
  font-family: "Courier New", SimSun, monospace;
  image-rendering: pixelated;
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
}

/* ---------- 背景层 ---------- */
/* ===================== 国际化鎏金深红背景 ===================== */
/* ===== 像素风金色马雨 ===== */
.mc-bg {
  position: fixed;
  inset: 0;
  z-index: 1;
  background: url(@/img/horse_bg.jpg) center/cover no-repeat;   /* 关键一句 */
  overflow: hidden;
}

.star-field {
  position: absolute;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
}

.pixel-star {
  position: absolute;
  width: 4px;
  height: 4px;
  background: #ffd700;
  /* 4×4 像素星 */
  box-shadow:
    1px 0 0 0 #ffd700,
    0 1px 0 0 #ffd700, 1px 1px 0 0 #fff, 2px 1px 0 0 #ffd700,
    1px 2px 0 0 #ffd700;
  animation: starFall linear infinite;
}

@keyframes starFall {
  to { transform: translateY(110vh) scale(var(--scale, 1)); }
}


/* ---------- 工作台 ---------- */
.check-in-wrapper {
  min-height: 100vh;
  display: flex;
  align-items: center;      /* 原来 flex-end → center */
  justify-content: center;
  padding-bottom: 0;        /* 去掉留空 */
}


.box {
  /* 去掉原来的 margin: 60px auto; */
  position: relative;
  z-index: 10;
  max-width: 320px;
  width: 100%;
  /* 其余原来样式不动 */
}


/* 1. placeholder 黑色描边（像素风） */
input::placeholder {
  color: #c7a252;
  font-weight: 700;
  opacity: 1;
  /* 上下左右各 1px 黑色描边 */
  text-shadow:
    -1px -1px 0 #000,
     1px -1px 0 #000,
    -1px  1px 0 #000,
     1px  1px 0 #000;
}

/* 2. 标题阴影背景（像素长条） */
h2 {
  position: relative;
  display: inline-block;
  padding: 4px 12px;
  color: #f3d58a;
  font-weight: 700;
  letter-spacing: 1px;
  /* 像素描边 */
  text-shadow:
    -1px -1px 0 #000,
     1px -1px 0 #000,
    -1px  1px 0 #000,
     1px  1px 0 #000;
}

/* 黑色像素背景条 */
h2::before {
  content: '';
  position: absolute;
  inset: 0;
  background: #000;
  z-index: -1;
  /* 像素外框 */
  box-shadow:
    0 0 0 2px #5d2c0f,
    0 0 0 4px #3e1e0a;
}


input {
  width: 100%;
  padding: 8px 4px;
  margin-bottom: 12px;
  font-size: 20px;
  color: #c7a252;
  font-weight: 700;
  opacity: 1;
  /* 上下左右各 1px 黑色描边 */
  text-shadow:
    -1px -1px 0 #000,
     1px -1px 0 #000,
    -1px  1px 0 #000,
     1px  1px 0 #000;
  background: transparent;        /* 关键：完全透明 */
  border: none;                   /* 去掉默认边框 */
  border-bottom: 2px solid #ffd700; /* 仅留金色底线 */
  outline: none;
  box-sizing: border-box;
}
/* 聚焦时底线高亮 */
input:focus {
  border-bottom-color: #ffec8b;
}
button {
  width: 100%;
  padding: 8px 0;
  font-size: 16px;
  background: #6b8e23;
  color: #fff;
  border: 2px solid #5d2c0f;
  cursor: pointer;
}
button:hover {
  background: linear-gradient(135deg, #ffd700 0%, #ffec8b 50%, #ffd700 100%);
  color: #6b0000;
  transition: all 0.25s;
}
button:active { transform: translateY(2px); }
.result {
  margin-top: 15px;
  color: #fde5a4;
  font-weight: bold;
  text-shadow: 1px 1px 0 #5d2c0f;
}

/* ---------- 确认对话框 ---------- */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.55);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}
.modal-box.pixel {
  background: #8b4513;
  border: 6px solid #5d2c0f;
  box-shadow: 0 0 0 2px #3e1e0a, 0 0 25px rgba(0,0,0,.7);
  padding: 25px 30px;
  max-width: 400px;
  text-align: center;
  color: #fde5a4;
}
.modal-text {
  margin: 0 0 20px;
  font-size: 16px;
  line-height: 1.5;
}
.modal-buttons {
  display: flex;
  gap: 15px;
  justify-content: center;
}
.pixel-btn {
  flex: 1;
  padding: 8px 0;
  font-size: 16px;
  border: 2px solid #5d2c0f;
  cursor: pointer;
  color: #fff;
}
.pixel-btn.yes { background: #6b8e23; }
.pixel-btn.yes:hover { background: #556b2f; }
.pixel-btn.no  { background: #b22222; }
.pixel-btn.no:hover  { background: #8b1a1a; }

/* ========== 永久展示窗体 - 高对比优雅版 ========== */
.final-box *,
.final-box {
  font-family: 'Germania One', cursive;
  font-weight: bold;
  color: #000;
  letter-spacing: 0.8px;
  text-shadow: 1px 1px 0 #ffd700, 2px 2px 0 rgba(0,0,0,.25); /* 金边阴影 */
}

.qr{
  width: 120px;
  height: 120px;
  display: block;
  border: 1px solid #ccc;   /* 调试用，能看到框 */
}


.final-box {
  /* 卡片底色：半透明白 → 跟任何深色背景都反差大 */
  background: rgba(255, 255, 255, 0.92);
  /* 像素风暗棕色描边 */
  border: 6px solid #5d2c0f;
  /* 双层阴影：内层做“凹陷”，外层做“悬浮” */
  box-shadow:
    inset 0 0 0 2px #3e1e0a,
    0 12px 24px rgba(0, 0, 0, 0.35);
  border-radius: 0; /* 保持像素风硬朗直角 */
  padding: 24px 28px;
  margin-top: 24px;
  text-align: center;
  color: #000; /* 全局黑色，高对比 */
  font-weight: bold;
  /* 防止像素字体被抗锯齿虚化 */
  image-rendering: pixelated;
}

/* 标题：再加大 + 金色描边，仪式感 */
.final-box h3 {
  margin: 0 0 12px;
  font-size: 22px;
  color: #000;
  text-shadow:
    1px 1px 0 #ffd700,
    -1px -1px 0 #ffd700,
    1px -1px 0 #ffd700,
    -1px 1px 0 #ffd700;
}

/* 副提示行：降低字号 + 深灰色，不抢镜 */
.final-box .tip {
  font-size: 13px;
  color: #444;
  font-weight: normal;
  margin: 8px 0 0;
}

/* 关键信息行（Table、Seat 等） */
.final-box p {
  margin: 6px 0;
  font-size: 16px;
  letter-spacing: 0.5px;
}

/* 高亮数值：金色 + 粗体 + 小描边 */
.final-box p span {
  color: #b8860b; /* 暗金色，比 #ffd700 柔和 */
  font-weight: bold;
  text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.25);
}

</style>
