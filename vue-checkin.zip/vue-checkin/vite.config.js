import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
  plugins: [vue()],
  server: {
    host: '0.0.0.0',
    port: 3001,
    hmr: {
      host: '139.224.133.69',
      protocol: 'ws', // 或者`wss`，取决于是否启用HTTPS
      clientPort: 3001,
      path: '/vite-hmr', // 自定义HMR路径
      overlay: false, // 禁用错误覆盖
      timeout: 30000, // 增加超时时间
    },
  },
});

